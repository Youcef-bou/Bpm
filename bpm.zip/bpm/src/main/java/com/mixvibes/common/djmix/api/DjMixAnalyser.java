package com.mixvibes.common.djmix.api;

public class DjMixAnalyser
{
    public static native void analyseTrack(String s1, String s2)
    public static native float getAnalysedBpm()
}
